import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(("192.168.68.110", 8080))  # כתובת השרת

with open("Smiley.jpeg", "rb") as file:
    while True:
        data = file.read(1024)
        if not data:
            break
        client_socket.send(data)

print("File sent!")
client_socket.close()
