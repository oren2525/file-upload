import socket

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(("0.0.0.0", 8080))
server_socket.listen(1)
print("Server listening...")

client_socket, addr = server_socket.accept()
print(f"Connected with {addr}")

with open("received.jpeg", "wb") as file:
    while True:
        data = client_socket.recv(1024)
        if not data:
            break
        file.write(data)

print("File received!")
client_socket.close()
server_socket.close()
